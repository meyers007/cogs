let avatarSynthesizer;
let peerConnection;
let enableDisplayTextAlignmentWithSpeech = true;
let isSpeaking = false;
let sessionActive = false;
// =================== CONNECT AVATAR SERVICE ===================
let talkingAvatarCharacter  = 'meg'
let talkingAvatarStyle      = 'formal'
let ttsVoice                = 'en-US-AvaMultilingualNeural'
let privateEndpointEnabled  = ""
let cogSvcRegion            = "eastus2"
let cogSvcSubKey            = '9OcMMkQJTgKIEio4ylE0wD53VJVdcvI4BI5FRCoECWaVV0yCLRm0JQQJ99BHACHYHv6XJ3w3AAAYACOGxmdD'
let privateEndpointInput    = ""

function connectAvatar() {
    let privateEndpoint = '';
    let speechSynthesisConfig;

    if (privateEndpointEnabled) {
        if (!privateEndpointInput.startsWith('https://')) {
            alert('Please fill in a valid Azure Speech endpoint (https://...).');
            return;
        }
        privateEndpoint = privateEndpointInput.slice(8);

        speechSynthesisConfig = SpeechSDK.SpeechConfig.fromEndpoint(
            new URL(`wss://${privateEndpoint}/tts/cognitiveservices/websocket/v1?enableTalkingAvatar=true`),
            cogSvcSubKey
        );
    } else {
        speechSynthesisConfig = SpeechSDK.SpeechConfig.fromSubscription(cogSvcSubKey, cogSvcRegion);
    }
    const avatarConfig = new SpeechSDK.AvatarConfig(talkingAvatarCharacter, talkingAvatarStyle);

    avatarSynthesizer = new SpeechSDK.AvatarSynthesizer(speechSynthesisConfig, avatarConfig);
    avatarSynthesizer.avatarEventReceived = (s, e) => {
        let offsetMsg = (e.offset === 0) ? '' : `, offset from session start: ${e.offset / 10000}ms.`;
        console.log('Avatar event: ' + e.description + offsetMsg);
    };

    // Get token from TTS service
    const xhr = new XMLHttpRequest();
    if (privateEndpointEnabled) {
        xhr.open("GET", `https://${privateEndpoint}/tts/cognitiveservices/avatar/relay/token/v1`);
    } else {
        xhr.open("GET", `https://${cogSvcRegion}.tts.speech.microsoft.com/cognitiveservices/avatar/relay/token/v1`);
    }
    xhr.setRequestHeader("Ocp-Apim-Subscription-Key", cogSvcSubKey);
    xhr.addEventListener("readystatechange", function() {
        if (this.readyState === 4) {
            const responseData = JSON.parse(this.responseText);
            const iceServerUrl = responseData.Urls[0];
            const iceServerUsername = responseData.Username;
            const iceServerCredential = responseData.Password;
            setupWebRTC(iceServerUrl, iceServerUsername, iceServerCredential);
        }
    });
    xhr.send();
}

// =================== SETUP WEBSOCKET & AVATAR ===================
function setupWebRTC(iceServerUrl, iceServerUsername, iceServerCredential) {
    peerConnection = new RTCPeerConnection({
        iceServers: [{
            urls: [iceServerUrl],
            username: iceServerUsername,
            credential: iceServerCredential
        }]
    });

    peerConnection.ontrack = (event) => {
        if (event.track.kind === 'audio') {
            let audioElement = document.createElement('audio');
            audioElement.id = 'audioPlayer';
            audioElement.srcObject = event.streams[0];
            audioElement.autoplay = true;
            audioElement.onplaying = () => console.log('WebRTC audio connected.');

            const remoteDiv = document.getElementById('remoteVideo');
            [...remoteDiv.childNodes].forEach(node => {
                if (node.localName === 'audio') remoteDiv.removeChild(node);
            });
            remoteDiv.appendChild(audioElement);
        } else if (event.track.kind === 'video') {
            let videoElement = document.createElement('video');
            videoElement.id = 'videoPlayer';
            videoElement.srcObject = event.streams[0];
            videoElement.autoplay = true;
            videoElement.playsInline = true;
            videoElement.onplaying = () => {
                console.log('WebRTC video connected.');
                const remoteDiv = document.getElementById('remoteVideo');
                [...remoteDiv.childNodes].forEach(node => {
                    if (node.localName === 'video') remoteDiv.removeChild(node);
                });
                remoteDiv.appendChild(videoElement);

                // Mark session active after 5 seconds
                setTimeout(() => { sessionActive = true; }, 5000);
            };
        }
    };

    peerConnection.addEventListener("datachannel", event => {
        const dataChannel = event.channel;
        dataChannel.onmessage = e => {
            const webRTCEvent = JSON.parse(e.data);
            console.log('[WebRTC event] ' + e.data);
        };
    });
    peerConnection.createDataChannel("eventChannel");

    peerConnection.oniceconnectionstatechange = () => {
        console.log("ICE state: " + peerConnection.iceConnectionState);
    };

    peerConnection.addTransceiver('video', { direction: 'sendrecv' });
    peerConnection.addTransceiver('audio', { direction: 'sendrecv' });

    avatarSynthesizer.startAvatarAsync(peerConnection)
    .then(r => {
        if (r.reason === SpeechSDK.ResultReason.SynthesizingAudioCompleted) {
            console.log('Success: Avatar started, resultId:' + r.resultId);
        } else {
            console.log('Unable to start avatar, resultId:' + r.resultId);
            if (r.reason === SpeechSDK.ResultReason.Canceled) {
                const cancellationDetails = SpeechSDK.CancellationDetails.fromResult(r);
                console.log('Cancelled: Avatar canceled: ' + cancellationDetails.errorDetails);
            }
        }
    })
    .catch(error => {
        console.log('Error": Avatar failed to start: ' + error);
    });
}

// =================== DISCONNECT AVATAR ===================
function disconnectAvatar() {
    if (avatarSynthesizer) avatarSynthesizer.close();
    sessionActive = false;
}
// =================== HTML ENCODE HELPER ===================
function htmlEncode(text) {
    const entityMap = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;',
        '/': '&#x2F;'
    };
    return String(text).replace(/[&<>"'\/]/g, (m) => entityMap[m]);
}
// =================== TTS FUNCTION ===================
function speak(text, endingSilenceMs = 0) {
    if (isSpeaking) {
        return;
    }
    const breakTime = (endingSilenceMs <=0) ? "" : `<break time='${endingSilenceMs}ms' />`

    let ssml = `<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis'
                     xmlns:mstts='http://www.w3.org/2001/mstts'
                     xml:lang='en-US'>
                  <voice name='${ttsVoice}'>
                    <mstts:ttsembedding>
                      <mstts:leadingsilence-exact value='0'/>
                      ${htmlEncode(text)}
                      ${breakTime}
                    </mstts:ttsembedding>
                  </voice>
                </speak>`;

    isSpeaking = true;

    avatarSynthesizer.speakSsmlAsync(ssml)
    .then(result => {
        if (result.reason === SpeechSDK.ResultReason.SynthesizingAudioCompleted) {
            console.log(`Speech synthesized: ${text}, resultId: ${result.resultId}`);
        } else {
            console.log(`Error speaking SSML. resultId: ${result.resultId}`);
        }
    })
    .catch(error => {
        console.log(`speakSsmlAsync error: ${error}`);
    });
    isSpeaking = false;
}

function stopSpeaking() {
    if ( !isSpeaking) {
        return;
    }
    if (avatarSynthesizer) {
        avatarSynthesizer.stopSpeakingAsync()
        .then(() => {
            isSpeaking = false;
        })
        .catch(err => console.log(`Error stopping speaking: ${err}`));
    }
}

